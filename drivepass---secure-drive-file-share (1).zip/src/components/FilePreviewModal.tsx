import React, { useState } from 'react';
import { X, Download, ExternalLink, FileSpreadsheet, Eye, AlertCircle } from 'lucide-react';
import { DriveFileItem } from '../types/share';

interface FilePreviewModalProps {
  file: DriveFileItem | null;
  onClose: () => void;
  onDownload: (file: DriveFileItem) => void;
  lang: 'th' | 'en';
}

export const FilePreviewModal: React.FC<FilePreviewModalProps> = ({
  file,
  onClose,
  onDownload,
  lang,
}) => {
  const [iframeError, setIframeError] = useState(false);

  if (!file) return null;

  const sheetsPreviewUrl = `https://drive.google.com/file/d/${file.id}/preview`;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="relative w-full max-w-5xl h-[88vh] bg-white border border-slate-200 rounded-3xl shadow-2xl flex flex-col overflow-hidden">
        {/* Modal Header in Clean Institutional Style */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 bg-slate-50/80">
          <div className="flex items-center gap-3 min-w-0">
            <div className="w-10 h-10 rounded-xl bg-emerald-50 border border-emerald-200 text-[#107c41] flex items-center justify-center shrink-0">
              <FileSpreadsheet className="w-5 h-5" />
            </div>
            <div className="min-w-0">
              <h3 className="text-sm font-bold text-slate-900 truncate max-w-xl">
                {file.name}
              </h3>
              <p className="text-xs text-slate-500 font-medium">
                {file.faculty && <span>{file.faculty} • </span>}
                {file.department && <span>{file.department} • </span>}
                <span>{file.size}</span>
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {/* Direct Open in Drive */}
            <a
              href={`https://drive.google.com/file/d/${file.id}/view`}
              target="_blank"
              rel="noreferrer"
              className="px-3 py-1.5 rounded-xl bg-white hover:bg-slate-100 border border-slate-200 text-slate-700 text-xs font-medium flex items-center gap-1.5 transition-colors"
            >
              <ExternalLink className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Google Drive</span>
            </a>

            {/* Download Button in MCU Ruby */}
            <button
              type="button"
              onClick={() => onDownload(file)}
              className="px-4 py-1.5 rounded-xl bg-[#b30253] hover:bg-[#960144] text-white text-xs font-semibold flex items-center gap-1.5 shadow-xs transition-all cursor-pointer"
            >
              <Download className="w-3.5 h-3.5" />
              <span>{lang === 'th' ? 'ดาวน์โหลดเอกสาร' : 'Download'}</span>
            </button>

            {/* Close Button */}
            <button
              type="button"
              onClick={onClose}
              className="w-8 h-8 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-500 hover:text-slate-800 flex items-center justify-center transition-colors cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Modal Iframe Content */}
        <div className="flex-1 bg-slate-100 relative flex flex-col items-center justify-center">
          {!iframeError ? (
            <iframe
              src={sheetsPreviewUrl}
              title={file.name}
              className="w-full h-full border-0 bg-white"
              onError={() => setIframeError(true)}
              allow="autoplay"
            />
          ) : (
            <div className="text-center p-8 max-w-md bg-white rounded-3xl border border-slate-200 shadow-sm">
              <AlertCircle className="w-12 h-12 text-amber-500 mx-auto mb-3" />
              <h4 className="text-base font-bold text-slate-800">
                {lang === 'th'
                  ? 'ไม่สามารถแสดงตัวอย่างภายในกรอบได้'
                  : 'Cannot embed preview directly'}
              </h4>
              <p className="text-xs text-slate-500 mt-2">
                {lang === 'th'
                  ? 'ท่านสามารถเปิดดูเอกสารผ่าน Google Drive หรือดาวน์โหลดไฟล์ Excel ลงเครื่องเพื่อเปิดใช้งาน'
                  : 'You can open this file in Google Drive or download it directly.'}
              </p>
              <div className="mt-5 flex items-center justify-center gap-3">
                <a
                  href={`https://drive.google.com/file/d/${file.id}/view`}
                  target="_blank"
                  rel="noreferrer"
                  className="px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-semibold flex items-center gap-2"
                >
                  <ExternalLink className="w-4 h-4" />
                  <span>{lang === 'th' ? 'เปิดบน Google Drive' : 'Open in Drive'}</span>
                </a>
                <button
                  type="button"
                  onClick={() => onDownload(file)}
                  className="px-4 py-2 rounded-xl bg-[#b30253] hover:bg-[#960144] text-white text-xs font-semibold flex items-center gap-2 cursor-pointer"
                >
                  <Download className="w-4 h-4" />
                  <span>{lang === 'th' ? 'ดาวน์โหลดลงเครื่อง' : 'Download File'}</span>
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
