import React, { useState, useEffect } from 'react';
import {
  Lock,
  KeyRound,
  Clock,
  Download,
  AlertTriangle,
  Eye,
  EyeOff,
  ShieldCheck,
  FolderLock,
  Info,
  ExternalLink,
  GraduationCap,
  FileSpreadsheet,
  CheckCircle2,
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { SharePackage } from '../types/share';
import { getTimeRemaining, formatThaiDateTime } from '../utils/timeFormat';

interface LockScreenProps {
  share: SharePackage;
  onUnlockSuccess: (unlockedData: SharePackage) => void;
  lang: 'th' | 'en';
}

export const LockScreen: React.FC<LockScreenProps> = ({
  share,
  onUnlockSuccess,
  lang,
}) => {
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [showHint, setShowHint] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [isShaking, setIsShaking] = useState(false);
  const [timeLeft, setTimeLeft] = useState(
    getTimeRemaining(share.security.expiresAt)
  );

  // Update timer every second
  useEffect(() => {
    if (!share.security.expiresAt) return;
    const interval = setInterval(() => {
      const remaining = getTimeRemaining(share.security.expiresAt);
      setTimeLeft(remaining);
    }, 1000);
    return () => clearInterval(interval);
  }, [share.security.expiresAt]);

  const isExpired =
    share.security.expiresAt !== null && timeLeft.isExpired;

  const isLimitReached =
    share.security.maxDownloads !== null &&
    share.security.maxDownloads !== undefined &&
    share.stats.totalDownloadsCount >= share.security.maxDownloads;

  const handleUnlock = async (e?: React.FormEvent, overridePwd?: string) => {
    if (e) e.preventDefault();
    if (isExpired || isLimitReached) return;

    const pwdToSubmit = overridePwd !== undefined ? overridePwd : password;
    if (!pwdToSubmit && share.security.requirePassword) {
      setErrorMsg(
        lang === 'th'
          ? 'กรุณากรอกรหัสผ่านเพื่อเข้าสู่ระบบ'
          : 'Please enter the access passcode'
      );
      triggerShake();
      return;
    }

    setIsLoading(true);
    setErrorMsg(null);

    try {
      const res = await fetch(`/api/shares/${share.id}/unlock`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ password: pwdToSubmit }),
      });

      const json = await res.json();
      if (res.ok && json.success) {
        try {
          confetti({
            particleCount: 80,
            spread: 70,
            origin: { y: 0.6 },
            colors: ['#b30253', '#f43f5e', '#d97706', '#10b981'],
          });
        } catch {}
        onUnlockSuccess(json.data);
      } else {
        setErrorMsg(
          json.message ||
            (lang === 'th'
              ? 'รหัสผ่านไม่ถูกต้อง กรุณาลองใหม่อีกครั้ง'
              : 'Incorrect passcode. Please try again.')
        );
        triggerShake();
      }
    } catch {
      // Offline fallback
      const expected = (share.security.password || '').trim().toLowerCase();
      const provided = pwdToSubmit.trim().toLowerCase();
      if (provided === expected || !share.security.requirePassword) {
        try {
          confetti({
            particleCount: 80,
            spread: 70,
            origin: { y: 0.6 },
          });
        } catch {}
        onUnlockSuccess({
          ...share,
          stats: { ...share.stats, unlockedCount: share.stats.unlockedCount + 1 },
        });
      } else {
        setErrorMsg(
          lang === 'th'
            ? 'รหัสผ่านไม่ถูกต้อง กรุณาลองใหม่อีกครั้ง'
            : 'Incorrect passcode. Please try again.'
        );
        triggerShake();
      }
    } finally {
      setIsLoading(false);
    }
  };

  const triggerShake = () => {
    setIsShaking(true);
    setTimeout(() => setIsShaking(false), 500);
  };

  return (
    <div className="w-full max-w-xl mx-auto px-4 py-8 md:py-12">
      {/* University Main Card */}
      <div
        className={`bg-white rounded-3xl border border-slate-200/90 shadow-xl shadow-slate-200/60 overflow-hidden transition-transform ${
          isShaking ? 'animate-[wiggle_0.4s_ease-in-out]' : ''
        }`}
      >
        {/* Top Header Card */}
        <div className="p-6 md:p-8 text-center border-b border-slate-100 bg-gradient-to-b from-rose-50/60 via-slate-50/40 to-white">
          {/* Official MCU Logo in Header */}
          <div className="flex justify-center mb-4">
            <img
              src="https://www.mcu.ac.th/directory_template_frontend/img/logo-v6-th.png"
              alt="MCU Emblem"
              className="h-14 sm:h-16 w-auto object-contain drop-shadow-xs"
            />
          </div>

          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-rose-50 border border-rose-200 text-[#b30253] text-xs font-semibold mb-3">
            <ShieldCheck className="w-3.5 h-3.5 text-[#b30253]" />
            <span>
              {lang === 'th'
                ? 'ระบบบริการเอกสารทางการศึกษา • ไม่ต้องล็อกอิน'
                : 'Zero-Login University Secure Document Portal'}
            </span>
          </div>

          <h1 className="text-xl md:text-2xl font-bold text-slate-900 tracking-tight leading-snug">
            {share.title}
          </h1>

          {share.description && (
            <p className="mt-2 text-xs md:text-sm text-slate-600 max-w-md mx-auto leading-relaxed">
              {share.description}
            </p>
          )}

          {/* Key Parameters Badges in Clean University Cards */}
          <div className="mt-5 grid grid-cols-2 md:grid-cols-3 gap-2.5 text-xs text-left">
            {/* Total files */}
            <div className="p-3 rounded-2xl bg-white border border-slate-200 shadow-2xs flex flex-col justify-between">
              <span className="text-slate-500 text-[11px]">
                {lang === 'th' ? 'จำนวนเอกสาร' : 'Total Files'}
              </span>
              <span className="font-bold text-slate-900 text-sm mt-0.5">
                {share.files.length} {lang === 'th' ? 'ไฟล์ (.xls)' : 'Files'}
              </span>
            </div>

            {/* Expiration badge */}
            <div
              className={`p-3 rounded-2xl border shadow-2xs flex flex-col justify-between ${
                isExpired
                  ? 'bg-rose-50 border-rose-200 text-rose-800'
                  : 'bg-white border-slate-200 text-slate-900'
              }`}
            >
              <div className="flex items-center gap-1 text-[11px] text-slate-500">
                <Clock className="w-3 h-3 text-[#b30253]" />
                <span>{lang === 'th' ? 'กำหนดหมดอายุ' : 'Expires'}</span>
              </div>
              <span
                className={`font-bold text-xs mt-0.5 truncate ${
                  isExpired ? 'text-rose-600' : 'text-[#b30253]'
                }`}
              >
                {share.security.expiresAt
                  ? isExpired
                    ? lang === 'th'
                      ? 'หมดอายุแล้ว'
                      : 'Expired'
                    : timeLeft.formattedText
                  : lang === 'th'
                  ? 'ตลอดไป'
                  : 'Never'}
              </span>
            </div>

            {/* Downloads limit */}
            <div
              className={`col-span-2 md:col-span-1 p-3 rounded-2xl border shadow-2xs flex flex-col justify-between ${
                isLimitReached
                  ? 'bg-amber-50 border-amber-200 text-amber-900'
                  : 'bg-white border-slate-200 text-slate-900'
              }`}
            >
              <div className="flex items-center gap-1 text-[11px] text-slate-500">
                <Download className="w-3 h-3 text-emerald-600" />
                <span>{lang === 'th' ? 'สิทธิ์ดาวน์โหลด' : 'Downloads'}</span>
              </div>
              <span
                className={`font-bold text-xs mt-0.5 truncate ${
                  isLimitReached ? 'text-amber-600' : 'text-slate-900'
                }`}
              >
                {share.security.maxDownloads !== null &&
                share.security.maxDownloads !== undefined
                  ? `${share.stats.totalDownloadsCount}/${share.security.maxDownloads} ครั้ง`
                  : lang === 'th'
                  ? 'ไม่จำกัด'
                  : 'Unlimited'}
              </span>
            </div>
          </div>
        </div>

        {/* Content Body */}
        <div className="p-6 md:p-8">
          {/* Status Blockers */}
          {isExpired ? (
            <div className="p-5 rounded-2xl bg-rose-50 border border-rose-200 text-center">
              <AlertTriangle className="w-8 h-8 text-rose-600 mx-auto mb-2" />
              <h3 className="text-sm font-bold text-rose-900">
                {lang === 'th'
                  ? 'ลิงก์เอกสารนี้หมดอายุการใช้งานแล้ว'
                  : 'This share link has expired'}
              </h3>
              <p className="text-xs text-rose-700 mt-1">
                {lang === 'th'
                  ? `ลิงก์นี้หมดอายุเมื่อ: ${formatThaiDateTime(
                      share.security.expiresAt
                    )} กรุณาติดต่อฝ่ายวิชาการเพื่อขอลิงก์ใหม่`
                  : `Expired on ${formatThaiDateTime(
                      share.security.expiresAt
                    )}. Please contact the administrator.`}
              </p>
            </div>
          ) : isLimitReached ? (
            <div className="p-5 rounded-2xl bg-amber-50 border border-amber-200 text-center">
              <Download className="w-8 h-8 text-amber-600 mx-auto mb-2" />
              <h3 className="text-sm font-bold text-amber-900">
                {lang === 'th'
                  ? 'สิทธิ์การดาวน์โหลดครบตามจำนวนที่กำหนดแล้ว'
                  : 'Download limit reached'}
              </h3>
              <p className="text-xs text-amber-700 mt-1">
                {lang === 'th'
                  ? `ลิงก์นี้จำกัดการดาวน์โหลดไว้ที่ ${share.security.maxDownloads} ครั้ง และมีการดาวน์โหลดครบแล้ว`
                  : `This link had a limit of ${share.security.maxDownloads} downloads.`}
              </p>
            </div>
          ) : (
            /* Active Unlock Form */
            <form onSubmit={handleUnlock} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1.5 flex items-center justify-between">
                  <span className="flex items-center gap-1.5">
                    <KeyRound className="w-3.5 h-3.5 text-[#b30253]" />
                    {lang === 'th'
                      ? 'กรอกรหัสผ่านเพื่อเข้าสู่ระบบ (Passcode)'
                      : 'Enter Security Passcode'}
                  </span>
                  {share.security.passwordHint && (
                    <button
                      type="button"
                      onClick={() => setShowHint(!showHint)}
                      className="text-[11px] text-[#b30253] hover:text-[#960144] font-medium flex items-center gap-1 transition-colors cursor-pointer"
                    >
                      <Info className="w-3 h-3" />
                      <span>
                        {showHint
                          ? lang === 'th'
                            ? 'ซ่อนคำใบ้'
                            : 'Hide hint'
                          : lang === 'th'
                          ? 'ดูคำใบ้รหัสผ่าน'
                          : 'Show hint'}
                      </span>
                    </button>
                  )}
                </label>

                {/* Password input container */}
                <div className="relative">
                  <input
                    type={showPassword ? 'text' : 'password'}
                    value={password}
                    onChange={(e) => {
                      setPassword(e.target.value);
                      if (errorMsg) setErrorMsg(null);
                    }}
                    placeholder={
                      lang === 'th'
                        ? 'กรอกรหัสผ่านเพื่อเข้าสู่ระบบ...'
                        : 'Enter passcode to access files...'
                    }
                    disabled={isLoading}
                    autoFocus
                    className="w-full px-4 py-3.5 rounded-2xl bg-white border border-slate-300 focus:border-[#b30253] focus:ring-3 focus:ring-rose-500/15 text-slate-900 placeholder-slate-400 text-sm tracking-wide transition-all outline-none pr-12 shadow-2xs font-medium"
                  />

                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 p-1 cursor-pointer"
                    title={showPassword ? 'Hide password' : 'Show password'}
                  >
                    {showPassword ? (
                      <EyeOff className="w-4 h-4" />
                    ) : (
                      <Eye className="w-4 h-4" />
                    )}
                  </button>
                </div>

                {/* Hint reveal */}
                {showHint && share.security.passwordHint && (
                  <div className="mt-2.5 p-3 rounded-xl bg-amber-50/80 border border-amber-200 text-xs text-amber-900 flex items-start gap-2">
                    <Info className="w-3.5 h-3.5 mt-0.5 shrink-0 text-amber-700" />
                    <span>
                      <strong className="font-semibold">
                        {lang === 'th' ? 'คำใบ้: ' : 'Hint: '}
                      </strong>
                      {share.security.passwordHint}
                    </span>
                  </div>
                )}

                {/* Error message */}
                {errorMsg && (
                  <div className="mt-2.5 p-3 rounded-xl bg-rose-50 border border-rose-200 text-xs text-rose-800 flex items-center gap-2 animate-in fade-in slide-in-from-top-1">
                    <AlertTriangle className="w-3.5 h-3.5 shrink-0 text-rose-600" />
                    <span>{errorMsg}</span>
                  </div>
                )}
              </div>

              {/* Unlock Submit Button in MCU Ruby Brand Color */}
              <button
                type="submit"
                disabled={isLoading}
                className="w-full py-3.5 px-6 rounded-2xl bg-[#b30253] hover:bg-[#960144] active:bg-[#7e0139] text-white font-semibold text-sm shadow-md shadow-rose-900/15 active:scale-[0.99] transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {isLoading ? (
                  <>
                    <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                    <span>
                      {lang === 'th' ? 'กำลังตรวจสอบรหัส...' : 'Verifying...'}
                    </span>
                  </>
                ) : (
                  <>
                    <Lock className="w-4 h-4" />
                    <span>
                      {lang === 'th'
                        ? 'ปลดล็อกและดูรายการแบบฟอร์ม'
                        : 'Unlock & View Forms'}
                    </span>
                  </>
                )}
              </button>
            </form>
          )}

          {/* Academic Instruction Note */}
          {share.customNote && (
            <div className="mt-5 p-3.5 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-600">
              <span className="font-semibold text-slate-800">
                {lang === 'th' ? 'คำชี้แจงสำหรับอาจารย์: ' : 'Faculty Notice: '}
              </span>
              {share.customNote}
            </div>
          )}

          {/* Source Folder Transparency Link */}
          {share.sourceDriveUrl && (
            <div className="mt-5 pt-4 border-t border-slate-100 text-center">
              <a
                href={share.sourceDriveUrl}
                target="_blank"
                rel="noreferrer"
                className="inline-flex items-center gap-1.5 text-xs text-slate-500 hover:text-[#b30253] transition-colors"
              >
                <span>
                  {lang === 'th'
                    ? 'ที่มา: โฟลเดอร์ Google Drive ต้นฉบับ'
                    : 'Source: Google Drive Folder'}
                </span>
                <ExternalLink className="w-3 h-3" />
              </a>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
