import React, { useState, useEffect } from 'react';
import {
  X,
  Copy,
  Check,
  QrCode,
  Download,
  Share2,
  Lock,
  Clock,
  Sparkles,
  MessageSquare,
  ExternalLink,
} from 'lucide-react';
import QRCode from 'qrcode';
import { SharePackage } from '../types/share';
import { formatThaiDateTime } from '../utils/timeFormat';

interface ShareModalProps {
  share: SharePackage;
  onClose: () => void;
  lang: 'th' | 'en';
}

export const ShareModal: React.FC<ShareModalProps> = ({
  share,
  onClose,
  lang,
}) => {
  const [copiedLink, setCopiedLink] = useState(false);
  const [copiedMessage, setCopiedMessage] = useState(false);
  const [qrDataUrl, setQrDataUrl] = useState<string>('');

  const shareUrl = `${window.location.origin}${window.location.pathname}?share=${share.id}`;

  useEffect(() => {
    QRCode.toDataURL(shareUrl, {
      width: 320,
      margin: 2,
      color: {
        dark: '#8e0040',
        light: '#ffffff',
      },
    })
      .then((url) => setQrDataUrl(url))
      .catch((err) => console.error('QR code generation failed:', err));
  }, [shareUrl]);

  const shareMessage = `📂 เอกสาร: ${share.title}
🏛️ วิทยาลัยสงฆ์พ่อขุนผาเมือง เพชรบูรณ์
🔗 ลิงก์เข้าดูและดาวน์โหลด: ${shareUrl}
🔑 รหัสผ่าน (Passcode): ${share.security.password || 'ไม่มีรหัสผ่าน'}
${share.security.passwordHint ? `💡 คำใบ้รหัสผ่าน: ${share.security.passwordHint}\n` : ''}⏳ กำหนดหมดอายุ: ${formatThaiDateTime(share.security.expiresAt)}
📥 จำกัดดาวน์โหลด: ${share.security.maxDownloads ? `${share.security.maxDownloads} ครั้ง` : 'ไม่จำกัด'}
⚠️ ระบบปลอดภัย ไม่ต้องสมัครสมาชิกหรือล็อกอินบัญชี Google ใดๆ ทั้งสิ้น`;

  const copyToClipboard = (text: string, isMsg = false) => {
    navigator.clipboard.writeText(text);
    if (isMsg) {
      setCopiedMessage(true);
      setTimeout(() => setCopiedMessage(false), 2000);
    } else {
      setCopiedLink(true);
      setTimeout(() => setCopiedLink(false), 2000);
    }
  };

  const downloadQrCode = () => {
    if (!qrDataUrl) return;
    const a = document.createElement('a');
    a.href = qrDataUrl;
    a.download = `qrcode_${share.id}.png`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="relative w-full max-w-lg bg-white border border-slate-200 rounded-3xl shadow-2xl overflow-hidden flex flex-col">
        {/* Modal Header */}
        <div className="flex items-center justify-between px-6 py-5 border-b border-slate-100 bg-slate-50/80">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-rose-50 border border-rose-200 text-[#b30253] flex items-center justify-center">
              <Share2 className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-900">
                {lang === 'th' ? 'แชร์ลิงก์เข้าถึงแบบฟอร์ม' : 'Share Protected Link'}
              </h3>
              <p className="text-[11px] text-slate-500 font-medium">
                {share.title}
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="w-8 h-8 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-500 hover:text-slate-800 flex items-center justify-center transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 space-y-5 overflow-y-auto max-h-[75vh]">
          {/* Share Link Box */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1.5">
              {lang === 'th' ? 'ลิงก์สำหรับส่งให้อาจารย์ผู้สอน (แชร์ต่อได้ทันที)' : 'Shareable URL'}
            </label>
            <div className="flex items-center gap-2">
              <input
                type="text"
                readOnly
                value={shareUrl}
                className="flex-1 px-3.5 py-2.5 rounded-xl bg-slate-50 border border-slate-300 text-[#b30253] font-mono text-xs select-all outline-none font-semibold"
              />
              <button
                type="button"
                onClick={() => copyToClipboard(shareUrl, false)}
                className="px-4 py-2.5 rounded-xl bg-[#b30253] hover:bg-[#960144] text-white text-xs font-semibold flex items-center gap-1.5 transition-all shadow-xs cursor-pointer"
              >
                {copiedLink ? (
                  <>
                    <Check className="w-3.5 h-3.5" />
                    <span>{lang === 'th' ? 'คัดลอกแล้ว' : 'Copied'}</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5" />
                    <span>{lang === 'th' ? 'คัดลอกลิงก์' : 'Copy'}</span>
                  </>
                )}
              </button>
            </div>
          </div>

          {/* Security Information Recap */}
          <div className="p-3.5 rounded-2xl bg-rose-50/50 border border-rose-100 grid grid-cols-2 gap-3 text-xs">
            <div>
              <span className="text-slate-500 text-[11px] flex items-center gap-1">
                <Lock className="w-3 h-3 text-[#b30253]" />
                <span>{lang === 'th' ? 'รหัสผ่านเข้าดู' : 'Passcode'}</span>
              </span>
              <span className="text-[#b30253] font-mono font-bold text-sm mt-0.5 block">
                {share.security.password || 'ไม่มี'}
              </span>
            </div>

            <div>
              <span className="text-slate-500 text-[11px] flex items-center gap-1">
                <Clock className="w-3 h-3 text-[#b30253]" />
                <span>{lang === 'th' ? 'กำหนดหมดอายุ' : 'Expiration'}</span>
              </span>
              <span className="text-slate-800 font-semibold text-xs mt-0.5 block truncate">
                {formatThaiDateTime(share.security.expiresAt)}
              </span>
            </div>
          </div>

          {/* QR Code Section */}
          <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 flex flex-col sm:flex-row items-center gap-4 text-center sm:text-left">
            <div className="w-28 h-28 bg-white p-2 rounded-xl border border-slate-200 shadow-2xs shrink-0 flex items-center justify-center">
              {qrDataUrl ? (
                <img
                  src={qrDataUrl}
                  alt="QR Code"
                  className="w-full h-full object-contain"
                />
              ) : (
                <QrCode className="w-8 h-8 text-slate-400 animate-pulse" />
              )}
            </div>

            <div className="min-w-0 flex-1">
              <h4 className="text-xs font-bold text-slate-900">
                {lang === 'th'
                  ? 'สแกน QR Code เพื่อเปิดบนโทรศัพท์มือถือ'
                  : 'Scan QR on Mobile'}
              </h4>
              <p className="text-[11px] text-slate-500 mt-1 leading-relaxed">
                {lang === 'th'
                  ? 'อาจารย์สามารถใช้กล้องสแกนและกรอกรหัสผ่านเพื่อเปิดดูหรือส่งต่อไปยังเครื่องคอมพิวเตอร์ได้ทันที'
                  : 'Recipient can scan and enter passcode directly on mobile.'}
              </p>
              <button
                type="button"
                onClick={downloadQrCode}
                className="mt-3 px-3 py-1.5 rounded-lg bg-white hover:bg-slate-100 border border-slate-200 text-slate-700 text-xs font-medium inline-flex items-center gap-1.5 transition-colors cursor-pointer"
              >
                <Download className="w-3.5 h-3.5" />
                <span>{lang === 'th' ? 'บันทึกรูป QR Code' : 'Save QR'}</span>
              </button>
            </div>
          </div>

          {/* Preformatted LINE / Chat Message Box */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="text-xs font-semibold text-slate-700 flex items-center gap-1.5">
                <MessageSquare className="w-3.5 h-3.5 text-[#b30253]" />
                <span>
                  {lang === 'th'
                    ? 'ข้อความสำเร็จรูปพร้อมส่ง (LINE กลุ่ม / Email)'
                    : 'Ready-to-Send Message'}
                </span>
              </label>

              <button
                type="button"
                onClick={() => copyToClipboard(shareMessage, true)}
                className="text-[11px] text-[#b30253] hover:text-[#960144] font-semibold transition-colors flex items-center gap-1 cursor-pointer"
              >
                {copiedMessage ? (
                  <>
                    <Check className="w-3 h-3" />
                    <span>{lang === 'th' ? 'คัดลอกข้อความแล้ว' : 'Copied'}</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3 h-3" />
                    <span>{lang === 'th' ? 'คัดลอกข้อความ' : 'Copy Text'}</span>
                  </>
                )}
              </button>
            </div>

            <textarea
              readOnly
              rows={4}
              value={shareMessage}
              className="w-full p-3 rounded-xl bg-slate-50 border border-slate-200 text-slate-700 font-mono text-[11px] leading-relaxed outline-none resize-none select-all font-medium"
            />
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-4 border-t border-slate-100 bg-slate-50/80 flex items-center justify-between">
          <a
            href={shareUrl}
            target="_blank"
            rel="noreferrer"
            className="text-xs text-[#b30253] hover:underline flex items-center gap-1.5 font-medium transition-colors"
          >
            <ExternalLink className="w-3.5 h-3.5" />
            <span>{lang === 'th' ? 'ทดสอบเปิดในหน้าต่างใหม่' : 'Test Open Link'}</span>
          </a>

          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-slate-200 hover:bg-slate-300 text-slate-700 text-xs font-semibold transition-colors cursor-pointer"
          >
            {lang === 'th' ? 'ปิดหน้าต่าง' : 'Close'}
          </button>
        </div>
      </div>
    </div>
  );
};
