import React from 'react';
import {
  ShieldCheck,
  Share2,
  Settings2,
  FolderLock,
  Globe,
  ExternalLink,
  PlusCircle,
  FileSpreadsheet,
  GraduationCap,
} from 'lucide-react';
import { SharePackage } from '../types/share';

interface NavbarProps {
  currentMode: 'recipient' | 'admin' | 'create';
  onModeChange: (mode: 'recipient' | 'admin' | 'create') => void;
  shares: SharePackage[];
  activeShareId: string;
  onSelectShare: (shareId: string) => void;
  onOpenShareModal: () => void;
  lang: 'th' | 'en';
  onToggleLang: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentMode,
  onModeChange,
  shares,
  activeShareId,
  onSelectShare,
  onOpenShareModal,
  lang,
  onToggleLang,
}) => {
  return (
    <header className="sticky top-0 z-40 w-full bg-white border-b border-slate-200/90 shadow-xs">
      {/* Top University Brand Ribbon */}
      <div className="bg-gradient-to-r from-[#8e0040] via-[#b30253] to-[#8e0040] text-white text-[11px] sm:text-xs py-1.5 px-4 font-normal">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-2">
            <GraduationCap className="w-3.5 h-3.5 text-amber-300" />
            <span className="font-medium tracking-wide">
              {lang === 'th'
                ? 'วิทยาลัยสงฆ์พ่อขุนผาเมือง เพชรบูรณ์'
                : 'Pho Khun Pha Mueang Buddhist College, Phetchabun'}
            </span>
          </div>

          <div className="hidden md:flex items-center gap-3 text-rose-100">
            <a
              href="https://www.mcu.ac.th"
              target="_blank"
              rel="noreferrer"
              className="hover:text-white transition-colors flex items-center gap-1"
            >
              <span>www.mcu.ac.th</span>
              <ExternalLink className="w-2.5 h-2.5" />
            </a>
            <span>•</span>
            <span>ระบบบริการใบกรอกคะแนน ป.ตรี 2569</span>
          </div>
        </div>
      </div>

      {/* Main Navbar Bar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 h-18 flex items-center justify-between gap-4">
        {/* Brand / Logo */}
        <div className="flex items-center gap-3 sm:gap-4">
          <div
            onClick={() => onModeChange('recipient')}
            className="flex items-center gap-3 cursor-pointer group"
          >
            {/* MCU Official Logo from mcu.ac.th */}
            <div className="h-11 flex items-center shrink-0">
              <img
                src="https://www.mcu.ac.th/directory_template_frontend/img/logo-v6-th.png"
                alt="MCU Logo"
                className="h-10 sm:h-11 w-auto object-contain"
                onError={(e) => {
                  // Fallback if image blocked
                  (e.target as HTMLElement).style.display = 'none';
                }}
              />
            </div>

            <div className="border-l border-slate-200 pl-3">
              <div className="flex items-center gap-1.5">
                <span className="font-bold text-sm sm:text-base tracking-tight text-slate-900 group-hover:text-[#b30253] transition-colors">
                  MCU Drive Share
                </span>
                <span className="px-1.5 py-0.5 rounded text-[10px] font-semibold bg-rose-50 text-[#b30253] border border-rose-200">
                  ระบบปลอดภัย
                </span>
              </div>
              <p className="text-[11px] text-slate-500 font-normal leading-tight hidden sm:block">
                {lang === 'th'
                  ? 'ระบบแชร์ใบกรอกคะแนนและเอกสารการศึกษา (ไม่ต้องล็อกอิน)'
                  : 'Zero-Login Academic Document & Score Sheet Portal'}
              </p>
            </div>
          </div>

          {/* Quick link switcher for multiple shares */}
          {shares.length > 1 && (
            <div className="hidden xl:block ml-2 pl-3 border-l border-slate-200">
              <select
                value={activeShareId}
                onChange={(e) => onSelectShare(e.target.value)}
                className="px-2.5 py-1.5 rounded-xl bg-slate-50 border border-slate-250 text-xs text-slate-700 outline-none focus:border-[#b30253]"
              >
                {shares.map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.title}
                  </option>
                ))}
              </select>
            </div>
          )}
        </div>

        {/* Right Nav Navigation */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* Mode Switcher Tabs */}
          <div className="bg-slate-100/90 p-1 rounded-xl border border-slate-200 flex items-center gap-1 text-xs font-medium">
            <button
              type="button"
              onClick={() => onModeChange('recipient')}
              className={`px-3 py-1.5 rounded-lg transition-all cursor-pointer flex items-center gap-1.5 ${
                currentMode === 'recipient'
                  ? 'bg-[#b30253] text-white shadow-xs font-semibold'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/50'
              }`}
            >
              <FileSpreadsheet className="w-3.5 h-3.5" />
              <span>
                {lang === 'th' ? 'หน้าผู้รับไฟล์' : 'Recipient Portal'}
              </span>
            </button>

            <button
              type="button"
              onClick={() => onModeChange('admin')}
              className={`px-3 py-1.5 rounded-lg transition-all cursor-pointer flex items-center gap-1.5 ${
                currentMode === 'admin'
                  ? 'bg-slate-800 text-white shadow-xs font-semibold'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/50'
              }`}
            >
              <Settings2 className="w-3.5 h-3.5" />
              <span>{lang === 'th' ? 'จัดการลิงก์' : 'Manage Links'}</span>
            </button>

            <button
              type="button"
              onClick={() => onModeChange('create')}
              className={`px-3 py-1.5 rounded-lg transition-all cursor-pointer flex items-center gap-1.5 ${
                currentMode === 'create'
                  ? 'bg-[#b30253] text-white shadow-xs font-semibold'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/50'
              }`}
            >
              <PlusCircle className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">
                {lang === 'th' ? 'สร้างลิงก์ใหม่' : 'New Link'}
              </span>
            </button>
          </div>

          {/* Share Button (opens QR / link modal) */}
          <button
            type="button"
            onClick={onOpenShareModal}
            className="px-3 py-1.5 rounded-xl bg-rose-50 hover:bg-rose-100 text-[#b30253] border border-rose-200/80 text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
            title="Share & QR Code"
          >
            <Share2 className="w-3.5 h-3.5" />
            <span className="hidden md:inline">
              {lang === 'th' ? 'แชร์ & QR' : 'Share'}
            </span>
          </button>

          {/* Language Toggle */}
          <button
            type="button"
            onClick={onToggleLang}
            className="px-2.5 py-1.5 rounded-xl bg-white hover:bg-slate-50 border border-slate-200 text-slate-600 hover:text-slate-900 text-xs font-medium flex items-center gap-1 transition-colors cursor-pointer"
          >
            <Globe className="w-3.5 h-3.5 text-[#b30253]" />
            <span className="uppercase font-semibold">{lang}</span>
          </button>
        </div>
      </div>
    </header>
  );
};
