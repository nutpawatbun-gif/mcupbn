import React, { useState } from 'react';
import {
  Share2,
  Lock,
  Clock,
  Download,
  Eye,
  Trash2,
  RefreshCw,
  ExternalLink,
  ShieldCheck,
  AlertTriangle,
  KeyRound,
  Check,
  Copy,
  Plus,
} from 'lucide-react';
import { SharePackage } from '../types/share';
import { formatThaiDateTime, getTimeRemaining } from '../utils/timeFormat';

interface ShareLinksListProps {
  shares: SharePackage[];
  onSelectShare: (share: SharePackage) => void;
  onOpenShareModal: (share: SharePackage) => void;
  onRefresh: () => void;
  onCreateNew: () => void;
  lang: 'th' | 'en';
}

export const ShareLinksList: React.FC<ShareLinksListProps> = ({
  shares,
  onSelectShare,
  onOpenShareModal,
  onRefresh,
  onCreateNew,
  lang,
}) => {
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [updatingId, setUpdatingId] = useState<string | null>(null);

  const copyPassword = (pwd: string, id: string) => {
    navigator.clipboard.writeText(pwd);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleResetQuota = async (id: string) => {
    setUpdatingId(id);
    try {
      await fetch(`/api/shares/${id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ resetDownloads: true }),
      });
      onRefresh();
    } catch (err) {
      console.error(err);
    } finally {
      setUpdatingId(null);
    }
  };

  const handleExtendExpiry = async (id: string, daysToAdd = 7) => {
    setUpdatingId(id);
    const newDate = new Date(Date.now() + daysToAdd * 24 * 60 * 60 * 1000).toISOString();
    try {
      await fetch(`/api/shares/${id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ expiresAt: newDate }),
      });
      onRefresh();
    } catch (err) {
      console.error(err);
    } finally {
      setUpdatingId(null);
    }
  };

  const handleDeleteShare = async (id: string) => {
    if (!confirm(lang === 'th' ? 'ต้องการลบหรือรีเซ็ตลิงก์นี้หรือไม่?' : 'Delete or reset this link?')) {
      return;
    }
    setUpdatingId(id);
    try {
      await fetch(`/api/shares/${id}`, {
        method: 'DELETE',
      });
      onRefresh();
    } catch (err) {
      console.error(err);
    } finally {
      setUpdatingId(null);
    }
  };

  return (
    <div className="w-full max-w-6xl mx-auto px-4 sm:px-6 py-6 md:py-8">
      {/* Header bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
        <div>
          <h2 className="text-xl md:text-2xl font-bold text-slate-900 tracking-tight flex items-center gap-2">
            <ShieldCheck className="w-6 h-6 text-[#b30253]" />
            <span>
              {lang === 'th' ? 'รายการลิงก์แชร์ที่มีการป้องกัน' : 'Active Protected Links'}
            </span>
          </h2>
          <p className="text-xs text-slate-500 mt-1">
            {lang === 'th'
              ? 'ตรวจสอบสถิติการดาวน์โหลด ปรับโควต้า หรือขยายวันหมดอายุสำหรับแบบฟอร์มเอกสาร'
              : 'Monitor visits, download quotas, and adjust security controls.'}
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={onRefresh}
            className="px-3.5 py-2 rounded-xl bg-white hover:bg-slate-50 border border-slate-200 text-slate-700 text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer shadow-2xs"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>{lang === 'th' ? 'รีเฟรช' : 'Refresh'}</span>
          </button>

          <button
            type="button"
            onClick={onCreateNew}
            className="px-4 py-2 rounded-xl bg-[#b30253] hover:bg-[#960144] text-white text-xs font-bold flex items-center gap-1.5 shadow-xs transition-all cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>{lang === 'th' ? 'สร้างลิงก์ใหม่' : 'New Link'}</span>
          </button>
        </div>
      </div>

      {/* Cards list */}
      <div className="space-y-4">
        {shares.map((share) => {
          const timeInfo = getTimeRemaining(share.security.expiresAt);
          const isExpired = share.security.expiresAt !== null && timeInfo.isExpired;

          const maxDl = share.security.maxDownloads;
          const currentDl = share.stats.totalDownloadsCount;
          const isLimitReached = maxDl !== null && maxDl !== undefined && currentDl >= maxDl;
          const dlPercent = maxDl ? Math.min(100, Math.round((currentDl / maxDl) * 100)) : 0;

          return (
            <div
              key={share.id}
              className="rounded-3xl bg-white border border-slate-200 p-5 md:p-6 shadow-xs hover:shadow-md transition-all"
            >
              <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
                {/* Info block */}
                <div className="min-w-0 flex-1">
                  <div className="flex flex-wrap items-center gap-2 mb-2">
                    {share.id === 'grade-sem1-2569' && (
                      <span className="px-2.5 py-0.5 rounded-full bg-rose-50 border border-rose-200 text-[#b30253] text-[11px] font-semibold">
                        {lang === 'th' ? 'ชุดมาตรฐาน มจร (Google Drive)' : 'MCU Official Package'}
                      </span>
                    )}

                    <span
                      className={`px-2.5 py-0.5 rounded-full text-[11px] font-medium border ${
                        isExpired
                          ? 'bg-rose-50 border-rose-200 text-rose-700'
                          : 'bg-slate-100 border-slate-200 text-slate-700'
                      }`}
                    >
                      {isExpired
                        ? lang === 'th'
                          ? 'หมดอายุแล้ว'
                          : 'Expired'
                        : timeInfo.formattedText}
                    </span>

                    {isLimitReached && (
                      <span className="px-2.5 py-0.5 rounded-full bg-amber-50 border border-amber-200 text-amber-800 text-[11px] font-medium">
                        {lang === 'th' ? 'สิทธิ์ดาวน์โหลดเต็มแล้ว' : 'Limit Reached'}
                      </span>
                    )}
                  </div>

                  <h3 className="text-base font-bold text-slate-900 tracking-tight">
                    {share.title}
                  </h3>
                  {share.description && (
                    <p className="text-xs text-slate-500 mt-0.5 line-clamp-1">
                      {share.description}
                    </p>
                  )}

                  {/* Grid details */}
                  <div className="mt-4 grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
                    {/* Password */}
                    <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-200">
                      <span className="text-slate-500 text-[11px] flex items-center gap-1 font-medium">
                        <KeyRound className="w-3 h-3 text-[#b30253]" />
                        <span>{lang === 'th' ? 'รหัสผ่าน' : 'Passcode'}</span>
                      </span>
                      <div className="flex items-center gap-1.5 mt-0.5">
                        <span className="font-mono font-bold text-[#b30253] text-xs">
                          {share.security.password || 'ไม่มี'}
                        </span>
                        {share.security.password && (
                          <button
                            type="button"
                            onClick={() => copyPassword(share.security.password!, share.id)}
                            className="text-slate-400 hover:text-slate-700 transition-colors p-0.5 cursor-pointer"
                            title="Copy Password"
                          >
                            {copiedId === share.id ? (
                              <Check className="w-3 h-3 text-emerald-600" />
                            ) : (
                              <Copy className="w-3 h-3" />
                            )}
                          </button>
                        )}
                      </div>
                    </div>

                    {/* Expiration date */}
                    <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-200">
                      <span className="text-slate-500 text-[11px] flex items-center gap-1 font-medium">
                        <Clock className="w-3 h-3 text-[#b30253]" />
                        <span>{lang === 'th' ? 'วันหมดอายุ' : 'Expires At'}</span>
                      </span>
                      <span className="text-slate-800 font-semibold text-xs mt-0.5 block truncate">
                        {formatThaiDateTime(share.security.expiresAt)}
                      </span>
                    </div>

                    {/* Downloads progress */}
                    <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-200">
                      <span className="text-slate-500 text-[11px] flex items-center gap-1 font-medium">
                        <Download className="w-3 h-3 text-emerald-600" />
                        <span>{lang === 'th' ? 'ดาวน์โหลด' : 'Downloads'}</span>
                      </span>
                      <span className="text-slate-900 font-bold text-xs mt-0.5 block">
                        {maxDl !== null && maxDl !== undefined
                          ? `${currentDl} / ${maxDl}`
                          : `${currentDl} (ไม่จำกัด)`}
                      </span>
                      {maxDl && (
                        <div className="w-full bg-slate-200 h-1.5 rounded-full mt-1.5 overflow-hidden">
                          <div
                            className={`h-full ${
                              isLimitReached ? 'bg-amber-500' : 'bg-[#b30253]'
                            }`}
                            style={{ width: `${dlPercent}%` }}
                          />
                        </div>
                      )}
                    </div>

                    {/* Visitors & Unlocks */}
                    <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-200">
                      <span className="text-slate-500 text-[11px] flex items-center gap-1 font-medium">
                        <Eye className="w-3 h-3 text-slate-600" />
                        <span>{lang === 'th' ? 'เข้าชม / ปลดล็อก' : 'Views / Unlocks'}</span>
                      </span>
                      <span className="text-slate-900 font-bold text-xs mt-0.5 block">
                        {share.stats.viewsCount} ครั้ง / {share.stats.unlockedCount} ปลดล็อก
                      </span>
                    </div>
                  </div>
                </div>

                {/* Actions column */}
                <div className="flex flex-wrap lg:flex-col items-center lg:items-end justify-end gap-2 shrink-0 pt-2 lg:pt-0 border-t lg:border-t-0 border-slate-100">
                  {/* Share button */}
                  <button
                    type="button"
                    onClick={() => onOpenShareModal(share)}
                    className="px-4 py-2 rounded-xl bg-[#b30253] hover:bg-[#960144] text-white text-xs font-bold flex items-center gap-1.5 shadow-2xs transition-all cursor-pointer"
                  >
                    <Share2 className="w-3.5 h-3.5" />
                    <span>{lang === 'th' ? 'แชร์ลิงก์ & QR' : 'Share & QR'}</span>
                  </button>

                  {/* Test unlock */}
                  <button
                    type="button"
                    onClick={() => onSelectShare(share)}
                    className="px-3.5 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 border border-slate-200 text-slate-800 text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
                  >
                    <Eye className="w-3.5 h-3.5 text-slate-600" />
                    <span>{lang === 'th' ? 'เปิดดูหน้าผู้รับ' : 'View Portal'}</span>
                  </button>

                  <div className="flex items-center gap-1.5">
                    {/* Reset Quota */}
                    <button
                      type="button"
                      onClick={() => handleResetQuota(share.id)}
                      disabled={updatingId === share.id}
                      className="p-2 rounded-xl bg-white hover:bg-slate-100 border border-slate-200 text-slate-600 hover:text-slate-900 text-xs transition-colors cursor-pointer"
                      title={lang === 'th' ? 'รีเซ็ตจำนวนดาวน์โหลด' : 'Reset downloads count'}
                    >
                      <RefreshCw className={`w-3.5 h-3.5 ${updatingId === share.id ? 'animate-spin' : ''}`} />
                    </button>

                    {/* Extend Expiry +7 Days */}
                    <button
                      type="button"
                      onClick={() => handleExtendExpiry(share.id, 7)}
                      disabled={updatingId === share.id}
                      className="px-2.5 py-1.5 rounded-xl bg-rose-50 hover:bg-rose-100 text-[#b30253] border border-rose-200 text-[11px] font-semibold transition-colors cursor-pointer"
                      title={lang === 'th' ? 'ขยายเวลาเพิ่ม 7 วัน' : 'Extend +7 days'}
                    >
                      +7 {lang === 'th' ? 'วัน' : 'days'}
                    </button>

                    {/* Delete / Reset */}
                    <button
                      type="button"
                      onClick={() => handleDeleteShare(share.id)}
                      disabled={updatingId === share.id}
                      className="p-2 rounded-xl bg-white hover:bg-rose-50 border border-slate-200 text-slate-400 hover:text-rose-600 transition-colors cursor-pointer"
                      title={lang === 'th' ? 'ลบ / รีเซ็ตลิงก์' : 'Delete or reset'}
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
