import React, { useState, useEffect } from 'react';
import {
  FolderLock,
  ShieldCheck,
  Lock,
  Clock,
  Download,
  Share2,
  ExternalLink,
  Info,
  CheckCircle2,
  GraduationCap,
  Building2,
} from 'lucide-react';
import { SharePackage } from './types/share';
import { createDefaultSharePackage } from './data/defaultDriveFolder';
import { Navbar } from './components/Navbar';
import { LockScreen } from './components/LockScreen';
import { FileBrowser } from './components/FileBrowser';
import { ShareManager } from './components/ShareManager';
import { ShareLinksList } from './components/ShareLinksList';
import { ShareModal } from './components/ShareModal';

export default function App() {
  const [shares, setShares] = useState<SharePackage[]>([createDefaultSharePackage()]);
  const [activeShareId, setActiveShareId] = useState<string>('grade-sem1-2569');
  const [unlockedShares, setUnlockedShares] = useState<Record<string, boolean>>({});
  const [currentMode, setCurrentMode] = useState<'recipient' | 'admin' | 'create'>('recipient');
  const [isShareModalOpen, setIsShareModalOpen] = useState(false);
  const [lang, setLang] = useState<'th' | 'en'>('th');
  const [isLoading, setIsLoading] = useState(true);

  // Load shares from backend on mount
  const fetchShares = async () => {
    try {
      const res = await fetch('/api/shares');
      if (res.ok) {
        const json = await res.json();
        if (json.data && json.data.length > 0) {
          const fullShares: SharePackage[] = json.data.map((item: any) => {
            const def = createDefaultSharePackage();
            return {
              ...def,
              ...item,
              files: item.files && item.files.length > 0 ? item.files : def.files,
            };
          });
          setShares(fullShares);
        }
      }
    } catch (e) {
      console.warn('API fetch fallback to local:', e);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchShares();

    // Check URL parameters for ?share=ID or hash
    const params = new URLSearchParams(window.location.search);
    const shareParam = params.get('share');
    if (shareParam) {
      setActiveShareId(shareParam);
      setCurrentMode('recipient');
    }
  }, []);

  // Current active share object
  const activeShare =
    shares.find((s) => s.id === activeShareId) || shares[0] || createDefaultSharePackage();

  // Handlers
  const handleUnlockSuccess = (unlockedPkg: SharePackage) => {
    setUnlockedShares((prev) => ({ ...prev, [unlockedPkg.id]: true }));
    setShares((prev) =>
      prev.map((s) => (s.id === unlockedPkg.id ? { ...s, ...unlockedPkg } : s))
    );
  };

  const handleLockSession = () => {
    setUnlockedShares((prev) => ({ ...prev, [activeShare.id]: false }));
  };

  const handleUpdateShareStats = (newTotalDownloads: number) => {
    setShares((prev) =>
      prev.map((s) => {
        if (s.id === activeShare.id) {
          return {
            ...s,
            stats: { ...s.stats, totalDownloadsCount: newTotalDownloads },
          };
        }
        return s;
      })
    );
  };

  const handleShareCreated = (newShare: SharePackage) => {
    setShares((prev) => [newShare, ...prev]);
    setActiveShareId(newShare.id);
    setCurrentMode('recipient');
    setIsShareModalOpen(true);
  };

  const isUnlocked = Boolean(unlockedShares[activeShare.id]);

  return (
    <div className="min-h-screen bg-[#f8fafc] text-slate-800 flex flex-col antialiased selection:bg-[#b30253] selection:text-white font-['Prompt',sans-serif]">
      {/* Top Navbar in MCU University Styling */}
      <Navbar
        currentMode={currentMode}
        onModeChange={(mode) => setCurrentMode(mode)}
        shares={shares}
        activeShareId={activeShare.id}
        onSelectShare={(id) => {
          setActiveShareId(id);
          setCurrentMode('recipient');
        }}
        onOpenShareModal={() => setIsShareModalOpen(true)}
        lang={lang}
        onToggleLang={() => setLang((prev) => (prev === 'th' ? 'en' : 'th'))}
      />

      {/* Main Body */}
      <main className="flex-1 flex flex-col justify-start">
        {currentMode === 'recipient' && (
          <div className="py-2">
            {!isUnlocked ? (
              <LockScreen
                share={activeShare}
                onUnlockSuccess={handleUnlockSuccess}
                lang={lang}
              />
            ) : (
              <FileBrowser
                share={activeShare}
                onLock={handleLockSession}
                onUpdateShareStats={handleUpdateShareStats}
                lang={lang}
              />
            )}
          </div>
        )}

        {currentMode === 'admin' && (
          <ShareLinksList
            shares={shares}
            onSelectShare={(share) => {
              setActiveShareId(share.id);
              setCurrentMode('recipient');
            }}
            onOpenShareModal={(share) => {
              setActiveShareId(share.id);
              setIsShareModalOpen(true);
            }}
            onRefresh={fetchShares}
            onCreateNew={() => setCurrentMode('create')}
            lang={lang}
          />
        )}

        {currentMode === 'create' && (
          <ShareManager
            onShareCreated={handleShareCreated}
            lang={lang}
          />
        )}
      </main>

      {/* Share Modal with QR code and Direct Link */}
      {isShareModalOpen && (
        <ShareModal
          share={activeShare}
          onClose={() => setIsShareModalOpen(false)}
          lang={lang}
        />
      )}

      {/* Institutional University Footer */}
      <footer className="border-t border-slate-200 bg-white py-8 px-4 text-xs text-slate-500 mt-12">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-6">
          {/* University info */}
          <div className="flex items-center gap-3">
            <img
              src="https://www.mcu.ac.th/directory_template_frontend/img/logo-v6-th.png"
              alt="MCU Logo"
              className="h-10 w-auto object-contain shrink-0"
            />
            <div>
              <p className="font-bold text-slate-800 text-xs sm:text-sm">
                วิทยาลัยสงฆ์พ่อขุนผาเมือง เพชรบูรณ์
              </p>
              <p className="text-[11px] text-slate-500">
                มหาวิทยาลัยมหาจุฬาลงกรณราชวิทยาลัย วิทยาลัยสงฆ์พ่อขุนผาเมือง เพชรบูรณ์
              </p>
            </div>
          </div>

          {/* System & Drive links */}
          <div className="flex flex-wrap items-center justify-center md:justify-end gap-4 text-xs text-slate-600">
            <div className="flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-[#b30253]" />
              <span>ระบบปลอดภัย ไม่ต้องลงชื่อเข้าใช้ (Zero-Login)</span>
            </div>
            <span>•</span>
            <a
              href="https://www.mcu.ac.th"
              target="_blank"
              rel="noreferrer"
              className="hover:text-[#b30253] transition-colors flex items-center gap-1 font-medium"
            >
              <span>เว็บไซต์มหาวิทยาลัย (mcu.ac.th)</span>
              <ExternalLink className="w-3 h-3" />
            </a>
            <span>•</span>
            <a
              href="https://drive.google.com/drive/folders/1dFHRchGV58Tbnk7_GPIX2XYpITw6EKIX?usp=sharing"
              target="_blank"
              rel="noreferrer"
              className="hover:text-[#b30253] transition-colors flex items-center gap-1 font-medium"
            >
              <span>โฟลเดอร์ Google Drive ต้นทาง</span>
              <ExternalLink className="w-3 h-3" />
            </a>
          </div>
        </div>
      </footer>
    </div>
  );
}
